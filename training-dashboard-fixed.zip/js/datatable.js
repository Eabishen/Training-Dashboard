// const dataTable = new DataTable("#enquirytable", {
//   responsive: true,
//   autoWidth: true,
//   scrollX: true,
//   stateSave: true,

//   //   dom: "lBfrtip", // 'l' for length changing, 'B' for buttons, 'f' for filtering, 'r' for processing, 't' for table, 'i' for info
//   //   buttons: [
//   //     {
//   //       extend: "pdf",
//   //       title: "Customized PDF Title",
//   //       filename: "customized_pdf_file_name",
//   //     },
//   //     {
//   //       extend: "excel",
//   //       title: "Customized EXCEL Title",
//   //       filename: "customized_excel_file_name",
//   //     },
//   //     {
//   //       extend: "csv",
//   //       filename: "customized_csv_file_name",
//   //     },
//   //   ],
// });
